# Verification and release handover

## Passed in this workspace

- TypeScript typecheck and optimized React production build.
- Six unit tests: integer-paisa arithmetic, refund allocation reversals, reservation vs physical inventory, parent scopes, invalid schema values and salted password verification.
- Eight requested end-to-end scenarios against an isolated local PostgreSQL engine (PGlite): enquiry admission into multiple programs; class attendance and daycare handover with authorised pickup; partial and final payments; material sales and deliveries; event collection/expense reporting; import validation and export; parent isolation; persistence after server restart, logout and fresh login.
- Additional API checks: duplicate admission, repeated payment submission with the same idempotency key, cross-family pickup, overdelivery, over-allocation, refundable-deposit isolation, credits, refunds, stale edits and untrusted request origins.
- Browser checks: desktop and mobile login and dashboard; billing and enquiry pipeline rendering; no JavaScript page errors or horizontal overflow in the inspected views.
- `render.yaml` validates against Render's current published JSON Schema. Render CLI/platform validation is not available in this workspace; resource creation remains untested.
- Versioned initial SQL migration runs successfully against the separate Neon `implementation-tests` branch, producing nine application tables. Its records/users remain empty. A read-only check confirmed zero public tables on the production branch.

The actual latest E2E run is recorded in `test-results.json`. All test credentials are generated at runtime; no operational data or default owner password is included.

## Infrastructure created

| Resource | Identifier | State |
|---|---|---|
| Neon project | `shiny-dew-84867995` | Separate iGrow project, Singapore, existing free organisation |
| Production branch | `br-spring-bird-b3gop6sh` | Untouched: zero public tables / no user data |
| Test branch | `br-twilight-sun-b3rq1l3n` | `implementation-tests`, migration verified, no operational records |
| GitHub | None created | Repository creation is absent from the available GitHub tools |
| Render | None created | User chose a different workspace; name/ID is outstanding |

SHA OS and its resources were not modified. No paid plan was purchased.

## Remaining release checks

1. Obtain a dedicated empty GitHub repository with connected-app access. Upload/commit this source, including the lockfile and migration.
2. Identify and connect the requested Render workspace.
3. Obtain explicit approval for the included schema migration on the new iGrow production branch. Automatic review rejected the earlier attempt because it treated database authorization as limited to the test branch. Do not bypass that rejection.
4. Resolve database connectivity from the deployed host. The local environment's direct Neon DNS lookup fails (`EAI_AGAIN`), while the Neon connector can query the database.
5. Deploy the free service with private database URLs, exact HTTPS origin and private bootstrap token. Verify health, secure cookies and one-time owner setup.
6. In production, create an explicitly authorised temporary validation record, reload, sign out and sign back in; verify persistence and cross-family isolation. Keep any real testing outside production unless the owner authorises it. Production persistence is **not yet verified**.
7. Complete a broader role-by-role acceptance review before storing real child records. Automated tests cover the stated flows; they are not a comprehensive security assessment.

## Known limits

Server-side permissions, SQL transactions, immutable posted ledger entries and private durable files are implemented. The initial app deliberately uses manual posting for recurring charges, late fees, instructor payouts, notices and payment recording. It has no external payment/messaging integration. CSV imports use UUID reference columns rather than matching ambiguous names. The UI paginates locally after fetching the user's authorised records; this needs server-side pagination before large deployments. PostgreSQL private files have a 2 MB limit. Richer assessment rubrics, galleries, automated recurrent jobs and a marketing website are outside this initial implementation; the core learning entries and private photo uploads are functional.
